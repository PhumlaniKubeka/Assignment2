﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace WarandPeaceApp
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_load_Click(object sender, EventArgs e)
        {
            var watch = System.Diagnostics.Stopwatch.StartNew();

            // load the   file
            OpenFileDialog openFileDialog = new OpenFileDialog();

            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {

                String FilePath = openFileDialog.FileName;
                textBox1.Text = File.ReadAllText(FilePath);
            }

            //Add words to listbox


            String allWords = textBox1.Text;
            String[] wordsArray = allWords.Split(' ', '.', ',', ';', ':', '?', '\n', '\r');

            foreach (String word in wordsArray)
            {
                if (!listBox1.Items.Contains(word))
                {
                    listBox1.Items.Add(word);
                }
            }

            watch.Stop();
            txttotaltime.AppendText($"Total Execution Time: {watch.ElapsedMilliseconds} ms");
           
        }

        private void button1_Click(object sender, EventArgs e)
        {
            String allWords = textBox1.Text;
            String[] wordsArray = allWords.Split(' ', '.', ',', ';', ':', '?', '\n', '\r');

            List<WordCounter> wordCounters = new List<WordCounter>();

            foreach (string w in wordsArray)
            {
                WordCounter foundword = wordCounters.Find(x => x.word == w);
                if (foundword == null)
                {
                    wordCounters.Add(new WordCounter(w, 1));
                }
                else
                {
                    foundword.frequency++;
                }
            }
                listView1.Columns.Add("Frequency");
                listView1.Columns.Add("Word");

                listView1.View = View.Details;
                listView1.GridLines = true;
                listView1.FullRowSelect = true;
                listView1.Sorting = SortOrder.Descending;

                foreach (WordCounter word in wordCounters.Take(50))
                {
                    String[] rowItem = new string[] { word.frequency.ToString("D5"), word.word };
                    listView1.Items.Add(new ListViewItem(rowItem));

                }
            }

        private void button2_Click(object sender, EventArgs e)
        {
            var watch = System.Diagnostics.Stopwatch.StartNew();

            String allWords = textBox1.Text;
            String[] wordsArray = allWords.Split(' ', '.', ',', ';', ':', '?', '\n', '\r');


            List<WordCounter> wordCounters = new List<WordCounter>();

            foreach (string w in wordsArray)
            {
                WordCounter overSix = wordCounters.Find(x => x.word.Length >= 6);
                if (overSix == null)
                {
                    {}
                }
                else
                {
                    overSix.frequency++;
                }
            }

            listView1.Columns.Add("Frequency");
            listView1.Columns.Add("Word");

            listView1.View = View.Details;
            listView1.GridLines = true;
            listView1.FullRowSelect = true;
            listView1.Sorting = SortOrder.Descending;

            foreach (WordCounter word in wordCounters.Take(50))
               
                {
                String[] rowItem = new string[] { word.frequency.ToString("D5"), word.word };
                listView1.Items.Add(new ListViewItem(rowItem));

            
            }

            watch.Stop();
            txtTop.AppendText($"Total Execution Time: {watch.ElapsedMilliseconds} ms");

        }

    }
    }


