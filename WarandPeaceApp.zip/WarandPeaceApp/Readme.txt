Technical Assignment:
Phumlani Kubeka
email:ptkubek27@gmail.com
Mobile Number: 0784731599
Date: 2020/10/08

General Questions

Describe what you enjoy about programming? Give examples: 

It gives you the allowance to create what you envision. Solutions do not seem to be far from your imagination, there are challenges that get the mind to think smarted instead of hard. With the current pandemic, Peoples hygiene patterns have sharpened, the utilization of technology has increased, this has brought the use of a mobile device to its peak, the use of online ordering systems solved the problem of people going out, when you do go out ,there are QR menus which allow you to interact with less common services. Security has increased with the use of Machine Learning. Programming has made mundane tasks quicker with the use of RPA. The entertainment industry has become heavy reliant on different programs to increase participation, whether it is online gambling, VAR in soccer events to streaming live concerts, the opportunities are limitless.

Describe the process you follow when writing code from requirements to delivery: 

I would first try find a pipeline on how to turn the requirements into a viable program. I would do more research on what is required, the type of language that is meant to utilized, if there exists similar solutions, how they were worked out and the outcome. 
Ensuring that adequate information is acquired about the full extent of one’s computer capabilities as well as the programming language of choice to identify the things that makes easy or intricate. More information may be required about the particular problem and an accompanying solution technique before one can identify how to build the program. And lastly, identifying various ways to build the program may come with associated advantages and disadvantages and therefore, calculated choices need to be made

Assignment:

6.Comment on how the application could be improved, and possibly made more efficient;
* The pplication can take in differnet files, from hrml, word doc and images using OCR.
* Having graphs and different metrics on the different words will help in terms of visual stats.
* Making the performance faster for larger files, will increase usabilty.



7. Comment on how you would improve the performance (speed) of the application?
* By allowing the program to function using one button. 
* Using less loops to read through the top 50 and reitirate to read the top 50 words with more than 6 letter.
* Less lines of code would have reduced the timing and made it more efficient aswell.
* Writing better code and making use of functions. 
* Make use of classes and methods, making them reusable.


8. Describe how the application could be turned into a cloud-based service;
* Designing the program as a collection of services. This helps make the program combine these services and provide what is currently needed at the moment in time.
* Looking at what services the program needs to communicate with and build those connections to the components.
* Keep in mind not to limit the app for scalabilit. 
* onverting the code to web app will allow users to access the program directly from the cloud.


9. Supply all your source code, together with your written responses to the above.




